package dsg.util.iface;

public interface TestRun {

}
