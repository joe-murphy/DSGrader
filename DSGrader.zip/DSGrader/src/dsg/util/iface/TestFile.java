package dsg.util.iface;

public interface TestFile {

}
