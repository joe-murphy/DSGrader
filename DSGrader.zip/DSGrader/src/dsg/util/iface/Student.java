package dsg.util.iface;

public interface Student {
	
}
