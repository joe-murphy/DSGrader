package dsg.util.impl;

public class Student {

}
